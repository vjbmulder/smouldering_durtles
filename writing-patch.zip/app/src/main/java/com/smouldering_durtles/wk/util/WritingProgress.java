/*
 * Copyright 2026 vjbmulder
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.smouldering_durtles.wk.util;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Local review schedule for kanji writing. Each kanji maps to {stage, dueAtMillis, totalSlips, reps}.
 * Stored on the device only; never sent to WaniKani.
 */
public final class WritingProgress {
    public static final String PREFS = "writing_practice";
    private static final long HOUR = 3600_000L;
    private static final long[] INTERVALS = {0, 4 * HOUR, 8 * HOUR, 24 * HOUR, 48 * HOUR, 168 * HOUR, 336 * HOUR, 720 * HOUR, 2880 * HOUR};

    private WritingProgress() {
        //
    }

    public static SharedPreferences prefs(final Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /**
     * Load the whole schedule.
     *
     * @param context any context
     * @return map from kanji to record
     */
    public static Map<String, long[]> load(final Context context) {
        final Map<String, long[]> out = new HashMap<>();
        try {
            final String raw = prefs(context).getString("progress", "{}");
            final JSONObject json = new JSONObject(raw == null ? "{}" : raw);
            final JSONArray names = json.names();
            if (names == null) {
                return out;
            }
            for (int i = 0; i < names.length(); i++) {
                final String k = names.getString(i);
                final JSONArray a = json.getJSONArray(k);
                out.put(k, new long[] {a.getLong(0), a.getLong(1), a.getLong(2), a.getLong(3)});
            }
        }
        catch (final Exception e) {
            // start fresh if the stored data is unreadable
        }
        return out;
    }

    /**
     * Save the whole schedule.
     *
     * @param context any context
     * @param progress the schedule
     */
    public static void save(final Context context, final Map<String, long[]> progress) {
        try {
            final JSONObject json = new JSONObject();
            for (final Map.Entry<String, long[]> e: progress.entrySet()) {
                final JSONArray a = new JSONArray();
                for (final long v: e.getValue()) {
                    a.put(v);
                }
                json.put(e.getKey(), a);
            }
            prefs(context).edit().putString("progress", json.toString()).apply();
        }
        catch (final Exception e) {
            // nothing sensible to do
        }
    }

    /**
     * Update the record for one kanji after an attempt.
     *
     * @param progress the schedule to update
     * @param kanji the kanji
     * @param outcome "clean", "miss" or "fail"
     * @param slips mistakes plus hints
     * @param maxStage cap the resulting stage (e.g. 1 after tracing); 0 for no cap
     */
    public static void record(final Map<String, long[]> progress, final String kanji, final String outcome,
                              final int slips, final int maxStage) {
        final long[] old = progress.get(kanji);
        final long[] p = old == null ? new long[] {0, 0, 0, 0} : old.clone();
        if ("clean".equals(outcome)) {
            p[0] = Math.min(8, p[0] + 1);
        }
        else if ("miss".equals(outcome)) {
            p[0] = slips <= 1 ? Math.max(1, p[0]) : Math.max(1, p[0] - 2);
        }
        else {
            p[0] = 1;
        }
        if (maxStage > 0) {
            p[0] = Math.min(p[0], maxStage);
        }
        p[1] = System.currentTimeMillis() + INTERVALS[(int) p[0]];
        p[2] += "clean".equals(outcome) ? 0 : Math.max(1, slips);
        p[3] += 1;
        progress.put(kanji, p);
    }
}

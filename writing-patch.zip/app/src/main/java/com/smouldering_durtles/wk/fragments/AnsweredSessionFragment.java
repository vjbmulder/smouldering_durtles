/*
 * Copyright 2019-2020 Ernst Jan Plugge <rmc@dds.nl>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.smouldering_durtles.wk.fragments;

import com.smouldering_durtles.wk.enums.SessionType;
import com.smouldering_durtles.wk.util.WritingProgress;
import com.smouldering_durtles.wk.views.WritingCanvasView;
import com.smouldering_durtles.wk.api.model.Meaning;
import com.smouldering_durtles.wk.api.model.Reading;
import android.widget.Button;
import android.widget.TextView;
import android.content.Context;
import java.util.HashMap;
import java.util.Map;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.smouldering_durtles.wk.GlobalSettings;
import com.smouldering_durtles.wk.R;
import com.smouldering_durtles.wk.activities.DigraphHelpActivity;
import com.smouldering_durtles.wk.db.model.SessionItem;
import com.smouldering_durtles.wk.db.model.Subject;
import com.smouldering_durtles.wk.enums.FragmentTransitionAnimation;
import com.smouldering_durtles.wk.enums.QuestionType;
import com.smouldering_durtles.wk.model.DigraphMatch;
import com.smouldering_durtles.wk.model.FloatingUiState;
import com.smouldering_durtles.wk.model.Question;
import com.smouldering_durtles.wk.proxy.ViewProxy;
import com.smouldering_durtles.wk.util.HapticUtil;
import com.smouldering_durtles.wk.util.ThemeUtil;
import com.smouldering_durtles.wk.views.SubjectInfoView;
import com.smouldering_durtles.wk.views.SwipingScrollView;

import java.util.Locale;

import javax.annotation.Nullable;

import static com.smouldering_durtles.wk.GlobalSettings.Review.enable_haptic_feedback_failure;
import static com.smouldering_durtles.wk.util.ObjectSupport.safe;

/**
 * Fragment for an answered non-Anki mode question.
 */
public final class AnsweredSessionFragment extends AbstractSessionFragment implements SwipingScrollView.OnSwipeListener {
    private @Nullable Question question;
    private @Nullable Subject subject;

    private final ViewProxy scrollView = new ViewProxy();
    private final ViewProxy nextButton = new ViewProxy();
    private final ViewProxy nextButton2 = new ViewProxy();
    private final ViewProxy specialButton1 = new ViewProxy();
    private final ViewProxy specialButton2 = new ViewProxy();
    private final ViewProxy specialButton3 = new ViewProxy();
    private final ViewProxy toastAnimation = new ViewProxy();
    private final ViewProxy questionView = new ViewProxy();
    private final ViewProxy questionEdit = new ViewProxy();
    private final ViewProxy subjectInfo = new ViewProxy();
    private final ViewProxy digraphMatchText = new ViewProxy();

    /**
     * The constructor.
     */
    public AnsweredSessionFragment() {
        super(R.layout.fragment_answered_question);
    }

    /**
     * Create a new instance with arguments set.
     *
     * @param subjectId the subject ID to show
     * @param questionType the type of the question to show
     * @return the fragment
     */
    public static AnsweredSessionFragment newInstance(final long subjectId, final QuestionType questionType) {
        final AnsweredSessionFragment fragment = new AnsweredSessionFragment();

        final Bundle args = new Bundle();
        args.putLong("subjectId", subjectId);
        args.putString("questionType", questionType.name());

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected void onCreateLocal() {
        final @Nullable Bundle args = getArguments();
        if (args != null) {
            final long subjectId = args.getLong("subjectId", -1);
            final @Nullable SessionItem item = session.findItemBySubjectId(subjectId);
            if (item != null) {
                subject = item.getSubject();
                question = item.getQuestionByTypeStr(args.getString("questionType"));
            }
        }
    }

    @Override
    protected void onResumeLocal() {
        nextButton.enableInteraction();
        nextButton.requestFocus();
    }

    @Override
    public void onViewCreatedLocal(final View view, final @Nullable Bundle savedInstanceState) {
        if (question == null || subject == null) {
            return;
        }

        onViewCreatedCommon(view, question, subject, false);

        scrollView.setDelegate(view, R.id.scrollView);
        nextButton.setDelegate(view, R.id.nextButton);
        nextButton2.setDelegate(view, R.id.nextButton2);
        specialButton1.setDelegate(view, R.id.specialButton1);
        specialButton2.setDelegate(view, R.id.specialButton2);
        specialButton3.setDelegate(view, R.id.specialButton3);
        toastAnimation.setDelegate(view, R.id.toastAnimation);
        questionView.setDelegate(view, R.id.questionView);
        questionEdit.setDelegate(view, R.id.questionEdit);
        subjectInfo.setDelegate(view, R.id.subjectInfo);
        digraphMatchText.setDelegate(view, R.id.digraphMatchText);
        scrollView.setSwipeListener(this);

        final @Nullable LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) questionView.getLayoutParams();
        if (params != null) {
            final int height = GlobalSettings.Display.getQuizQuestionViewHeight();
            params.height = height > 0 ? dp2px(height): ViewGroup.LayoutParams.WRAP_CONTENT;
            params.weight = 0;
            questionView.setLayoutParams(params);
        }

        if (session.isCorrect()) {
            questionEdit.setBackgroundColor(ThemeUtil.getColor(R.attr.correctColorBackground));
        }
        else {
            questionEdit.setBackgroundColor(ThemeUtil.getColor(R.attr.incorrectColorBackground));
            if (enable_haptic_feedback_failure()) {
                Log.d("HapticFeedback", "Vibing");
                HapticUtil.onWrong(requireView(), requireContext());
            }
        }

        questionEdit.setSingleLine();
        questionEdit.setText(FloatingUiState.getCurrentAnswer());
        questionEdit.setTextSize(GlobalSettings.Font.getFontSizeQuestionEdit());
        questionEdit.setTextColor(ThemeUtil.getColor(androidx.appcompat.R.attr.colorPrimary));
        if (question.getType().isAscii()) {
            questionEdit.setRootLocale();
        }
        if (question.getType().isKana()) {
            questionEdit.setJapaneseLocale();
        }

        // Show or hide the subject info dump
        subjectInfo.setToolbar(null);
        subjectInfo.setMaxFontSize(GlobalSettings.Font.getMaxFontSizeQuiz());
        subjectInfo.setContainerType(SubjectInfoView.ContainerType.ANSWERED_QUESTION);
        subjectInfo.setSubject(this, subject);

        final View.OnClickListener listener = this::advanceNext;
        nextButton.setOnClickListener(listener);
        nextButton2.setOnClickListener(listener);

        if (FloatingUiState.lastVerdict == null) {
            digraphMatchText.setVisibility(false);
        }
        else {
            final @Nullable DigraphMatch match = FloatingUiState.lastVerdict.getDigraphMatch();
            if (match != null) {
                digraphMatchText.setText(String.format(Locale.ROOT, "Your answer was incorrect because you mixed up the regular kana %c"
                                + " and the small kana %c. Tap this message for more information about the difference between small and regular kana.",
                        match.getRegularKana(), match.getSmallKana()));
                digraphMatchText.setClickableAndNotFocusable(true);
                digraphMatchText.setOnClickListener(v -> goToActivity(DigraphHelpActivity.class));
                digraphMatchText.setVisibility(true);
            }
            else {
                digraphMatchText.setVisibility(false);
            }
        }

        safe(() -> maybeShowWriting(view));
    }

    /** Kanji written during reviews recently, so a kanji is only written once per session. */
    private static final Map<String, Long> recentlyWritten = new HashMap<>();
    private static final long WRITE_AGAIN_AFTER = 2 * 3600_000L;

    /**
     * After both questions for a kanji are answered in a review, ask for it to be written from memory.
     */
    private void maybeShowWriting(final View view) {
        final @Nullable Subject s = subject;
        final @Nullable SessionItem item = getItem();
        final View panel = view.findViewById(R.id.reviewWritingPanel);
        if (panel == null || s == null || item == null || !item.isFinished()) {
            return;
        }
        if (session.getType() != SessionType.REVIEW && session.getType() != SessionType.SELF_STUDY) {
            return;
        }
        if (!s.getType().isKanji() || !s.hasStrokeData() || s.getCharacters() == null) {
            return;
        }
        final Context context = view.getContext();
        if (!WritingProgress.prefs(context).getBoolean("reviewWriting", true)) {
            return;
        }
        final String kanji = s.getCharacters();
        final @Nullable Long last = recentlyWritten.get(kanji);
        if (last != null && System.currentTimeMillis() - last < WRITE_AGAIN_AFTER) {
            return;
        }
        recentlyWritten.put(kanji, System.currentTimeMillis());

        final View scroll = view.findViewById(R.id.scrollView);
        final View next2 = view.findViewById(R.id.nextButton2);
        final TextView title = view.findViewById(R.id.reviewWritingTitle);
        final TextView readings = view.findViewById(R.id.reviewWritingReadings);
        final TextView feedback = view.findViewById(R.id.reviewWritingFeedback);
        final View tools = view.findViewById(R.id.reviewWritingTools);
        final Button cont = view.findViewById(R.id.reviewWritingContinue);
        final WritingCanvasView canvas = view.findViewById(R.id.reviewWritingCanvas);
        final int defaultColor = feedback.getCurrentTextColor();
        final int error0 = ThemeUtil.getColor(R.attr.incorrectColorBackground);
        final int error = error0 == 0xFFFF0000 ? 0xFFD03030 : error0;

        String meaning = "";
        for (final Meaning m: s.getMeanings()) {
            if (m.isPrimary() && m.getMeaning() != null) {
                meaning = m.getMeaning();
                break;
            }
        }
        if (meaning.isEmpty()) {
            meaning = s.getOneMeaning();
        }
        title.setText("Now write it: " + meaning);
        title.setTextColor(s.getBackgroundColor());
        final StringBuilder r = new StringBuilder();
        for (final Reading rd: s.getOnYomiReadings()) {
            if (rd.getReading() != null) {
                r.append(r.length() == 0 ? "on: " : ", ").append(rd.getReading());
            }
        }
        final int onLen = r.length();
        for (final Reading rd: s.getKunYomiReadings()) {
            if (rd.getReading() != null) {
                r.append(r.length() == onLen ? (onLen == 0 ? "kun: " : "   kun: ") : ", ").append(rd.getReading());
            }
        }
        readings.setText(r.toString());

        final int bg = ThemeUtil.getColor(R.attr.colorBackground);
        final boolean light = ThemeUtil.isLightColor(bg);
        canvas.setColors(light ? 0xFFFFFFFF : 0xFF1E1E1E, light ? 0xFF1B1F22 : 0xFFEDEDED, s.getBackgroundColor(), error);
        final String len = WritingProgress.prefs(context).getString("leniency", "normal");
        canvas.setTolerance("strict".equals(len) ? 12f : "relaxed".equals(len) ? 21f : 16f);
        canvas.setStrokeData(s.getParsedStrokeData(), false);

        final Runnable close = () -> {
            panel.setVisibility(View.GONE);
            scroll.setVisibility(View.VISIBLE);
            if (next2 != null) {
                next2.setVisibility(View.VISIBLE);
            }
        };

        canvas.setListener(new WritingCanvasView.Listener() {
            @Override
            public void onFeedback(final String message, final int kind) {
                safe(() -> {
                    feedback.setText(message);
                    feedback.setTextColor(kind == 2 ? error : defaultColor);
                });
            }

            @Override
            public void onCompleted(final int mistakes, final int hints, final boolean revealed, final boolean traced) {
                safe(() -> {
                    final int slips = mistakes + hints;
                    final String outcome = revealed ? "fail" : slips == 0 ? "clean" : "miss";
                    final Map<String, long[]> progress = WritingProgress.load(context);
                    WritingProgress.record(progress, kanji, outcome, slips, 0);
                    WritingProgress.save(context, progress);
                    feedback.setTextColor("fail".equals(outcome) ? error : defaultColor);
                    feedback.setText("clean".equals(outcome) ? "Correct! Every stroke in order."
                            : "fail".equals(outcome) ? "Shown. It will come back in Writing practice soon."
                            : String.format(Locale.ROOT, "Done with %d slip%s.", slips, slips == 1 ? "" : "s"));
                    tools.setVisibility(View.GONE);
                    cont.setVisibility(View.VISIBLE);
                });
            }
        });

        view.findViewById(R.id.reviewWritingHint).setOnClickListener(v -> safe(canvas::hint));
        view.findViewById(R.id.reviewWritingReveal).setOnClickListener(v -> safe(canvas::reveal));
        view.findViewById(R.id.reviewWritingSkip).setOnClickListener(v -> safe(close::run));
        cont.setOnClickListener(v -> safe(close::run));

        feedback.setTextColor(defaultColor);
        feedback.setText(String.format(Locale.ROOT, "%d stroke%s. Write it from memory.", canvas.getStrokeCount(), canvas.getStrokeCount() == 1 ? "" : "s"));
        tools.setVisibility(View.VISIBLE);
        cont.setVisibility(View.GONE);
        scroll.setVisibility(View.GONE);
        if (next2 != null) {
            next2.setVisibility(View.GONE);
        }
        panel.setVisibility(View.VISIBLE);
    }

    @Override
    public String getToolbarTitle() {
        return question == null ? "" : question.getTitle();
    }

    @Override
    public int getToolbarBackgroundColor() {
        return subject == null ? 0 : subject.getBackgroundColor();
    }

    @Override
    public void enableInteraction() {
        safe(() -> {
            nextButton.enableInteraction();
            nextButton2.enableInteraction();
            specialButton1.enableInteraction();
            specialButton2.enableInteraction();
            specialButton3.enableInteraction();
            interactionEnabled = true;
        });
    }

    @Override
    public void disableInteraction() {
        safe(() -> {
            interactionEnabled = false;
            nextButton.disableInteraction();
            nextButton2.disableInteraction();
            specialButton1.disableInteraction();
            specialButton2.disableInteraction();
            specialButton3.disableInteraction();
        });
    }

    @SuppressWarnings("SuspiciousGetterSetter")
    @Override
    public Subject getCurrentSubject() {
        return subject;
    }

    @Override
    public @Nullable SessionItem getItem() {
        return question == null ? null : question.getItem();
    }

    @Override
    public @Nullable Question getQuestion() {
        return question;
    }

    @Override
    public @Nullable Subject getSubject() {
        return subject;
    }

    @Override
    public void showOrHideSoftInput() {
        hideSoftInput();
    }

    @Override
    public FragmentTransitionAnimation getAnimation(final AbstractSessionFragment newFragment) {
        if (newFragment instanceof UnansweredSessionFragment && question == newFragment.getQuestion()) {
            return session.getQuestionChoiceReason().getAnimation();
        }
        if (newFragment.getQuestion() != null && newFragment.getQuestion() != question) {
            return session.getQuestionChoiceReason().getAnimation();
        }
        return FragmentTransitionAnimation.RTL;
    }

    @Override
    public void updateViews() {
        safe(() -> {
            if (GlobalSettings.Review.getShowAnswerToast()) {
                showPreviousAnswerToast(toastAnimation, session.isCorrect() ? R.raw.success : R.raw.fail);
            }
        });
    }

    private void advanceNext(View v) {
        safe(() -> {
            if (!interactionEnabled) {
                return;
            }
            if (session.isNextButtonFrozen()) {
                return;
            }
            disableInteraction();
            session.advance();
        });
    }

    @Override
    public void onSwipeLeft(SwipingScrollView view) {
        // Do nothing (match previous behavior before this fragment became a SwipingScrollView)
    }

    @Override
    public void onSwipeRight(SwipingScrollView view) {
        this.advanceNext(view);
    }
}

/*
 * Copyright 2026 vjbmulder
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.smouldering_durtles.wk.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Nullable;

/**
 * A square writing area on which the user writes a kanji stroke by stroke. Every stroke is compared with the
 * KanjiVG stroke data: position, shape, direction and order must match. Accepted strokes snap to the reference
 * stroke. The SVG path parser is adapted from StrokeDiagramView.
 */
public final class WritingCanvasView extends View {
    /**
     * Callbacks from the writing area.
     */
    public interface Listener {
        /**
         * Show a feedback message.
         *
         * @param message the text
         * @param kind 0 = neutral, 1 = good, 2 = error
         */
        void onFeedback(String message, int kind);

        /**
         * The kanji is complete (written or revealed).
         *
         * @param mistakes number of rejected strokes
         * @param hints number of hints used
         * @param revealed true if the user asked to be shown the whole kanji
         * @param traced true if the outline was visible at any point
         */
        void onCompleted(int mistakes, int hints, boolean revealed, boolean traced);
    }

    private static final Pattern svgInstructionPattern = Pattern.compile("([a-zA-Z])([^a-zA-Z]+)");
    private static final Pattern svgCoordinatesPattern = Pattern.compile("-?\\d*\\.?\\d*");
    private static final int N = 32;
    private static final float BOX = 109f;

    private static final class Stroke {
        final Path path;
        final float length;
        final float[][] pts = new float[N][2];

        Stroke(final Path path) {
            this.path = path;
            final PathMeasure pm = new PathMeasure(path, false);
            float len = pm.getLength();
            // A path can hold more than one contour; use the first one for matching.
            this.length = len;
            final float[] pos = new float[2];
            for (int i = 0; i < N; i++) {
                pm.getPosTan(len * i / (N - 1), pos, null);
                pts[i][0] = pos[0];
                pts[i][1] = pos[1];
            }
        }
    }

    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint livePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private List<Stroke> strokes = Collections.emptyList();
    private int done = 0;
    private int mistakes = 0;
    private int hints = 0;
    private int missesOnCurrent = 0;
    private boolean finished = false;
    private boolean revealed = false;
    private boolean outline = false;
    private boolean traced = false;
    private boolean busy = false;
    private boolean penSeen = false;
    private boolean showNumbers = false;
    private float tolerance = 16f;

    private final List<float[]> live = new ArrayList<>();
    private final Path livePath = new Path();
    private @Nullable Path badPath = null;
    private int badAlpha = 0;
    private @Nullable Path hintPath = null;
    private float hintProgress = 0;
    private int hintAlpha = 255;
    private int animatingStroke = -1;
    private float animatingProgress = 0;
    private @Nullable ValueAnimator animator = null;
    private @Nullable Listener listener = null;

    private float scale = 1;
    private float offsetX = 0;
    private float offsetY = 0;

    public WritingCanvasView(final Context context) {
        super(context);
        init();
    }

    public WritingCanvasView(final Context context, final @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WritingCanvasView(final Context context, final @Nullable AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        for (final Paint p: new Paint[] {outlinePaint, inkPaint, livePaint, hintPaint, badPaint}) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(4f);
        }
        livePaint.setStrokeWidth(3.4f);
        badPaint.setStrokeWidth(3f);
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(0.4f);
        gridPaint.setPathEffect(new DashPathEffect(new float[] {1.6f, 1.6f}, 0));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1.2f);
        numberPaint.setTextSize(5f);
        numberPaint.setFakeBoldText(true);
        dotPaint.setStyle(Paint.Style.FILL);
        setColors(0xFFFFFFFF, 0xFF202020, 0xFFAA00AA, 0xFFD03030);
    }

    /**
     * Set the colours used for drawing.
     *
     * @param background the paper colour
     * @param ink the ink colour
     * @param accent the colour for hints and stroke numbers
     * @param error the colour for rejected strokes
     */
    public void setColors(final int background, final int ink, final int accent, final int error) {
        setBackgroundColor(background);
        inkPaint.setColor(ink);
        livePaint.setColor(ink);
        outlinePaint.setColor((ink & 0x00FFFFFF) | 0x33000000);
        gridPaint.setColor((ink & 0x00FFFFFF) | 0x55000000);
        borderPaint.setColor((ink & 0x00FFFFFF) | 0x66000000);
        hintPaint.setColor(accent);
        dotPaint.setColor(accent);
        numberPaint.setColor(accent);
        badPaint.setColor(error);
        invalidate();
    }

    public void setListener(final @Nullable Listener listener) {
        this.listener = listener;
    }

    /**
     * How forgiving the stroke check is: 21 relaxed, 16 normal, 12 strict.
     *
     * @param tolerance average allowed distance in KanjiVG units
     */
    public void setTolerance(final float tolerance) {
        this.tolerance = tolerance;
    }

    /**
     * Load a new kanji.
     *
     * @param strokeData KanjiVG path data, one string per stroke
     * @param showOutline show the reference strokes in grey for tracing
     */
    public void setStrokeData(final List<String> strokeData, final boolean showOutline) {
        cancelAnimation();
        final List<Stroke> list = new ArrayList<>();
        for (final String s: strokeData) {
            final Path p = new Path();
            try {
                parse(p, s);
            }
            catch (final Exception e) {
                // ignore broken stroke data
            }
            list.add(new Stroke(p));
        }
        strokes = list;
        done = 0;
        mistakes = 0;
        hints = 0;
        missesOnCurrent = 0;
        finished = false;
        revealed = false;
        busy = false;
        showNumbers = false;
        outline = showOutline;
        traced = showOutline;
        live.clear();
        livePath.reset();
        badPath = null;
        hintPath = null;
        invalidate();
    }

    public int getStrokeCount() {
        return strokes.size();
    }

    public int getDoneCount() {
        return done;
    }

    public boolean isFinished() {
        return finished;
    }

    public boolean isOutlineShown() {
        return outline;
    }

    /**
     * Show or hide the grey reference outline.
     *
     * @param show true to show
     */
    public void setOutline(final boolean show) {
        outline = show;
        if (show) {
            traced = true;
        }
        invalidate();
    }

    /**
     * Start the current kanji again from the first stroke.
     */
    public void restart() {
        if (finished || busy) {
            return;
        }
        done = 0;
        missesOnCurrent = 0;
        invalidate();
        feedback("Start again from stroke 1.", 0);
    }

    /**
     * Animate the next stroke as a hint.
     */
    public void hint() {
        hintInternal(false);
    }

    private void hintInternal(final boolean auto) {
        if (finished || busy || done >= strokes.size()) {
            return;
        }
        hints++;
        busy = true;
        final Stroke s = strokes.get(done);
        hintPath = s.path;
        hintAlpha = 255;
        cancelAnimation();
        final ValueAnimator a = ValueAnimator.ofFloat(0, 1);
        a.setDuration(700);
        a.addUpdateListener(v -> {
            hintProgress = (float) v.getAnimatedValue();
            invalidate();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(final Animator animation) {
                busy = false;
                final ValueAnimator fade = ValueAnimator.ofInt(255, 0);
                fade.setStartDelay(900);
                fade.setDuration(600);
                fade.addUpdateListener(v -> {
                    hintAlpha = (int) v.getAnimatedValue();
                    invalidate();
                });
                fade.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(final Animator animation) {
                        hintPath = null;
                        invalidate();
                    }
                });
                fade.start();
            }
        });
        animator = a;
        a.start();
        if (!auto) {
            feedback(String.format(Locale.ROOT, "Stroke %d starts at the dot.", done + 1), 0);
        }
    }

    /**
     * Draw the remaining strokes one by one and finish the kanji as 'shown'.
     */
    public void reveal() {
        if (finished || busy) {
            return;
        }
        revealed = true;
        feedback("Watch the stroke order. It will come back soon.", 0);
        animateFrom(done, true);
    }

    /**
     * Replay the whole kanji with stroke numbers.
     */
    public void replay() {
        if (busy) {
            return;
        }
        showNumbers = true;
        done = 0;
        animateFrom(0, false);
    }

    private void animateFrom(final int start, final boolean completeAfter) {
        if (start >= strokes.size()) {
            busy = false;
            animatingStroke = -1;
            done = strokes.size();
            invalidate();
            if (completeAfter) {
                complete();
            }
            return;
        }
        busy = true;
        animatingStroke = start;
        animatingProgress = 0;
        final ValueAnimator a = ValueAnimator.ofFloat(0, 1);
        a.setDuration(380);
        a.addUpdateListener(v -> {
            animatingProgress = (float) v.getAnimatedValue();
            invalidate();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(final Animator animation) {
                done = start + 1;
                animatingStroke = -1;
                postDelayed(() -> animateFrom(start + 1, completeAfter), 120);
            }
        });
        animator = a;
        a.start();
    }

    private void cancelAnimation() {
        if (animator != null) {
            animator.removeAllListeners();
            animator.cancel();
            animator = null;
        }
        animatingStroke = -1;
    }

    private void feedback(final String message, final int kind) {
        if (listener != null) {
            listener.onFeedback(message, kind);
        }
    }

    private void complete() {
        finished = true;
        outline = false;
        invalidate();
        if (listener != null) {
            listener.onCompleted(mistakes, hints, revealed, traced);
        }
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        final int w = MeasureSpec.getSize(widthMeasureSpec);
        int h = MeasureSpec.getSize(heightMeasureSpec);
        if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED || h == 0) {
            h = (int) (getResources().getDisplayMetrics().heightPixels * 0.55f);
        }
        final int size = Math.min(w, h);
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        final float size = Math.min(w, h);
        scale = size / BOX;
        offsetX = (w - size) / 2;
        offsetY = (h - size) / 2;
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scale, scale);

        canvas.drawLine(BOX / 2, 0, BOX / 2, BOX, gridPaint);
        canvas.drawLine(0, BOX / 2, BOX, BOX / 2, gridPaint);
        canvas.drawRect(0.6f, 0.6f, BOX - 0.6f, BOX - 0.6f, borderPaint);

        if (outline) {
            for (final Stroke s: strokes) {
                canvas.drawPath(s.path, outlinePaint);
            }
        }
        for (int i = 0; i < done && i < strokes.size(); i++) {
            canvas.drawPath(strokes.get(i).path, inkPaint);
            if (showNumbers) {
                drawNumber(canvas, i);
            }
        }
        if (animatingStroke >= 0 && animatingStroke < strokes.size()) {
            final Stroke s = strokes.get(animatingStroke);
            final Path seg = new Path();
            new PathMeasure(s.path, false).getSegment(0, s.length * animatingProgress, seg, true);
            canvas.drawPath(seg, inkPaint);
            if (showNumbers) {
                drawNumber(canvas, animatingStroke);
            }
        }
        if (hintPath != null) {
            final Path seg = new Path();
            final PathMeasure pm = new PathMeasure(hintPath, false);
            pm.getSegment(0, pm.getLength() * hintProgress, seg, true);
            hintPaint.setAlpha(hintAlpha);
            dotPaint.setAlpha(hintAlpha);
            canvas.drawPath(seg, hintPaint);
            final float[] pos = new float[2];
            pm.getPosTan(0, pos, null);
            canvas.drawCircle(pos[0], pos[1], 2.6f, dotPaint);
        }
        if (badPath != null) {
            badPaint.setAlpha(badAlpha);
            canvas.drawPath(badPath, badPaint);
        }
        if (!livePath.isEmpty()) {
            canvas.drawPath(livePath, livePaint);
        }
        canvas.restore();
    }

    private void drawNumber(final Canvas canvas, final int i) {
        final float[] p = strokes.get(i).pts[0];
        canvas.drawText(Integer.toString(i + 1), Math.max(2, p[0] - 5), Math.max(6, p[1] - 2), numberPaint);
    }

    private float[] toBox(final float x, final float y) {
        return new float[] {(x - offsetX) / scale, (y - offsetY) / scale};
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        final int tool = event.getToolType(0);
        if (tool == MotionEvent.TOOL_TYPE_STYLUS) {
            penSeen = true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (finished || busy || strokes.isEmpty() || (penSeen && tool == MotionEvent.TOOL_TYPE_FINGER)) {
                    return false;
                }
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                live.clear();
                livePath.reset();
                final float[] p = toBox(event.getX(), event.getY());
                live.add(p);
                livePath.moveTo(p[0], p[1]);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (live.isEmpty()) {
                    return false;
                }
                for (int h = 0; h < event.getHistorySize(); h++) {
                    final float[] p = toBox(event.getHistoricalX(h), event.getHistoricalY(h));
                    live.add(p);
                    livePath.lineTo(p[0], p[1]);
                }
                final float[] p = toBox(event.getX(), event.getY());
                live.add(p);
                livePath.lineTo(p[0], p[1]);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP: {
                if (live.isEmpty()) {
                    return false;
                }
                final float[] p = toBox(event.getX(), event.getY());
                live.add(p);
                final List<float[]> pts = new ArrayList<>(live);
                final Path drawn = new Path(livePath);
                live.clear();
                livePath.reset();
                handleStroke(pts, drawn);
                invalidate();
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL: {
                live.clear();
                livePath.reset();
                invalidate();
                return true;
            }
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private static final class Drawn {
        final float[][] pts = new float[N][2];
        float length = 0;
    }

    private static Drawn resample(final List<float[]> raw) {
        final Drawn out = new Drawn();
        final int n = raw.size();
        final float[] cum = new float[n];
        for (int i = 1; i < n; i++) {
            cum[i] = cum[i - 1] + (float) Math.hypot(raw.get(i)[0] - raw.get(i - 1)[0], raw.get(i)[1] - raw.get(i - 1)[1]);
        }
        final float total = cum[n - 1];
        out.length = total;
        if (total == 0 || n < 2) {
            for (int i = 0; i < N; i++) {
                out.pts[i][0] = raw.get(0)[0];
                out.pts[i][1] = raw.get(0)[1];
            }
            return out;
        }
        int j = 0;
        for (int i = 0; i < N; i++) {
            final float t = total * i / (N - 1);
            while (j < n - 2 && cum[j + 1] < t) {
                j++;
            }
            final float seg = cum[j + 1] - cum[j] == 0 ? 1 : cum[j + 1] - cum[j];
            final float f = (t - cum[j]) / seg;
            out.pts[i][0] = raw.get(j)[0] + (raw.get(j + 1)[0] - raw.get(j)[0]) * f;
            out.pts[i][1] = raw.get(j)[1] + (raw.get(j + 1)[1] - raw.get(j)[1]) * f;
        }
        return out;
    }

    private static float avgDist(final float[][] a, final float[][] b, final boolean reverse) {
        float sum = 0;
        for (int i = 0; i < N; i++) {
            final float[] q = reverse ? b[N - 1 - i] : b[i];
            sum += (float) Math.hypot(a[i][0] - q[0], a[i][1] - q[1]);
        }
        return sum / N;
    }

    /** 0 = no match, 1 = match, 2 = right stroke drawn backwards. */
    private int judge(final Drawn u, final Stroke e) {
        final float tol = tolerance + 0.08f * e.length;
        final float d = avgDist(u.pts, e.pts, false);
        final float dr = avgDist(u.pts, e.pts, true);
        final float lo = tolerance >= 20 ? 0.3f : tolerance <= 12 ? 0.5f : 0.4f;
        final float hi = tolerance >= 20 ? 2.6f : tolerance <= 12 ? 1.7f : 2.1f;
        final boolean shortStroke = e.length < 14;
        final boolean lenOk = shortStroke ? u.length < 45 : (u.length / e.length > lo && u.length / e.length < hi);
        final float startD = (float) Math.hypot(u.pts[0][0] - e.pts[0][0], u.pts[0][1] - e.pts[0][1]);
        if (lenOk && d < tol && (d <= dr || shortStroke) && startD < tol * 1.6f) {
            return 1;
        }
        if (lenOk && !shortStroke && dr < tol && dr < d * 0.8f) {
            return 2;
        }
        return 0;
    }

    private void handleStroke(final List<float[]> raw, final Path drawn) {
        if (done >= strokes.size()) {
            return;
        }
        if (raw.size() < 2) {
            raw.add(new float[] {raw.get(0)[0] + 0.5f, raw.get(0)[1] + 0.5f});
        }
        final Drawn u = resample(raw);
        final int r = judge(u, strokes.get(done));
        if (r == 1) {
            missesOnCurrent = 0;
            done++;
            if (done >= strokes.size()) {
                complete();
            }
            else {
                feedback(String.format(Locale.ROOT, "Stroke %d of %d", done + 1, strokes.size()), 0);
            }
            return;
        }
        mistakes++;
        missesOnCurrent++;
        flashBad(drawn);
        String msg;
        if (r == 2) {
            msg = "Right stroke, wrong direction. Try it the other way.";
        }
        else {
            int later = -1;
            for (int j = done + 1; j < strokes.size(); j++) {
                if (judge(u, strokes.get(j)) == 1) {
                    later = j;
                    break;
                }
            }
            msg = later >= 0
                    ? String.format(Locale.ROOT, "That's stroke %d. Stroke %d comes first.", later + 1, done + 1)
                    : String.format(Locale.ROOT, "Not quite. Try stroke %d again.", done + 1);
        }
        if (missesOnCurrent >= 3) {
            missesOnCurrent = 0;
            msg += " Here's how it goes.";
            feedback(msg, 2);
            hintInternal(true);
        }
        else {
            feedback(msg, 2);
        }
    }

    private void flashBad(final Path drawn) {
        badPath = drawn;
        badAlpha = 230;
        final ValueAnimator a = ValueAnimator.ofInt(230, 0);
        a.setStartDelay(250);
        a.setDuration(700);
        a.addUpdateListener(v -> {
            badAlpha = (int) v.getAnimatedValue();
            invalidate();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(final Animator animation) {
                badPath = null;
                invalidate();
            }
        });
        a.start();
    }

    /* ---- SVG path parsing (adapted from StrokeDiagramView, Copyright 2019-2020 Ernst Jan Plugge, Apache 2.0) ---- */

    private static List<Float> splitCoordinates(final CharSequence str) {
        final Matcher matcher = svgCoordinatesPattern.matcher(str);
        final List<Float> result = new ArrayList<>();
        while (matcher.find()) {
            final @Nullable String s = matcher.group();
            if (s != null && !s.isEmpty() && !s.equals("-") && !s.equals(".")) {
                result.add(Float.parseFloat(s));
            }
        }
        return result;
    }

    private static void parse(final Path path, final CharSequence pathData) {
        final Matcher matcher = svgInstructionPattern.matcher(pathData);
        float lastX = 0;
        float lastY = 0;
        float lastX1 = 0;
        float lastY1 = 0;
        float startX = 0;
        float startY = 0;
        boolean curve = false;
        while (matcher.find()) {
            final @Nullable String cmd = matcher.group(1);
            final @Nullable String args = matcher.group(2);
            if (cmd == null || args == null) {
                continue;
            }
            final char command = cmd.charAt(0);
            final List<Float> c = splitCoordinates(args);
            switch (command) {
                case 'M':
                case 'm': {
                    if (c.size() < 2) {
                        break;
                    }
                    float x = c.get(0);
                    float y = c.get(1);
                    if (command == 'm') {
                        x += lastX;
                        y += lastY;
                    }
                    path.moveTo(x, y);
                    startX = x;
                    startY = y;
                    lastX = x;
                    lastY = y;
                    for (int i = 2; i + 1 < c.size(); i += 2) {
                        float lx = c.get(i);
                        float ly = c.get(i + 1);
                        if (command == 'm') {
                            lx += lastX;
                            ly += lastY;
                        }
                        path.lineTo(lx, ly);
                        lastX = lx;
                        lastY = ly;
                    }
                    curve = false;
                    break;
                }
                case 'L':
                case 'l': {
                    for (int i = 0; i + 1 < c.size(); i += 2) {
                        float x = c.get(i);
                        float y = c.get(i + 1);
                        if (command == 'l') {
                            x += lastX;
                            y += lastY;
                        }
                        path.lineTo(x, y);
                        lastX = x;
                        lastY = y;
                    }
                    curve = false;
                    break;
                }
                case 'H':
                case 'h': {
                    for (final float v: c) {
                        lastX = command == 'h' ? lastX + v : v;
                        path.lineTo(lastX, lastY);
                    }
                    curve = false;
                    break;
                }
                case 'V':
                case 'v': {
                    for (final float v: c) {
                        lastY = command == 'v' ? lastY + v : v;
                        path.lineTo(lastX, lastY);
                    }
                    curve = false;
                    break;
                }
                case 'C':
                case 'c': {
                    for (int i = 0; i + 5 < c.size(); i += 6) {
                        float x1 = c.get(i);
                        float y1 = c.get(i + 1);
                        float x2 = c.get(i + 2);
                        float y2 = c.get(i + 3);
                        float x = c.get(i + 4);
                        float y = c.get(i + 5);
                        if (command == 'c') {
                            x1 += lastX;
                            y1 += lastY;
                            x2 += lastX;
                            y2 += lastY;
                            x += lastX;
                            y += lastY;
                        }
                        path.cubicTo(x1, y1, x2, y2, x, y);
                        lastX1 = x2;
                        lastY1 = y2;
                        lastX = x;
                        lastY = y;
                    }
                    curve = true;
                    break;
                }
                case 'S':
                case 's': {
                    for (int i = 0; i + 3 < c.size(); i += 4) {
                        float x2 = c.get(i);
                        float y2 = c.get(i + 1);
                        float x = c.get(i + 2);
                        float y = c.get(i + 3);
                        if (command == 's') {
                            x2 += lastX;
                            y2 += lastY;
                            x += lastX;
                            y += lastY;
                        }
                        final float x1 = curve ? 2 * lastX - lastX1 : lastX;
                        final float y1 = curve ? 2 * lastY - lastY1 : lastY;
                        path.cubicTo(x1, y1, x2, y2, x, y);
                        lastX1 = x2;
                        lastY1 = y2;
                        lastX = x;
                        lastY = y;
                        curve = true;
                    }
                    break;
                }
                case 'Z':
                case 'z': {
                    path.close();
                    lastX = startX;
                    lastY = startY;
                    curve = false;
                    break;
                }
                default:
                    // 'T' carries the stroke number label in Smouldering Durtles' stroke data; not needed here.
                    break;
            }
        }
    }
}

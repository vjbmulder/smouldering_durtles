/*
 * Copyright 2026 vjbmulder
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.smouldering_durtles.wk.activities;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.smouldering_durtles.wk.R;
import com.smouldering_durtles.wk.WkApplication;
import com.smouldering_durtles.wk.api.model.Meaning;
import com.smouldering_durtles.wk.api.model.Reading;
import com.smouldering_durtles.wk.db.model.Subject;
import com.smouldering_durtles.wk.enums.SubjectType;
import com.smouldering_durtles.wk.util.ThemeUtil;
import com.smouldering_durtles.wk.util.WritingProgress;
import com.smouldering_durtles.wk.views.WritingCanvasView;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Nullable;

import static com.smouldering_durtles.wk.util.ObjectSupport.runAsync;
import static com.smouldering_durtles.wk.util.ObjectSupport.safe;

/**
 * Kanji writing practice: write kanji you have passed on WaniKani from memory, with stroke order checking.
 * Progress is kept in a separate local schedule and never sent to WaniKani.
 */
public final class WritingPracticeActivity extends AbstractActivity {
    private static final String PREFS = WritingProgress.PREFS;

    /** One kanji that can be practised. */
    private static final class Item {
        String characters = "";
        int level = 0;
        boolean started = false;
        boolean passed = false;
        String meaning = "";
        String otherMeanings = "";
        String onyomi = "";
        String kunyomi = "";
        List<String> strokes = Collections.emptyList();
    }

    /** Result of one question in the current round. */
    private static final class Result {
        final Item item;
        final String outcome;
        final int slips;

        Result(final Item item, final String outcome, final int slips) {
            this.item = item;
            this.outcome = outcome;
            this.slips = slips;
        }
    }

    /** Everything loaded from the database in the background. */
    private static final class Loaded {
        final List<Item> items = new ArrayList<>();
        int userLevel = 1;
    }

    private List<Item> allItems = new ArrayList<>();
    private List<Item> candidates = new ArrayList<>();
    private int userLevel = 1;
    private int startLevel = 0;
    private TextView startLevelText;
    private RadioGroup gate;
    private final Map<String, long[]> progress = new HashMap<>();
    private List<Item> queue = new ArrayList<>();
    private final List<Result> results = new ArrayList<>();
    private int index = 0;
    private int defaultFeedbackColor = 0;

    private View startView;
    private View questionView;
    private View summaryView;
    private TextView startStats;
    private Button startButton;
    private RadioGroup roundSize;
    private RadioGroup leniency;
    private CheckBox traceNew;
    private LinearLayout promptBand;
    private TextView progressText;
    private TextView levelText;
    private TextView meaningText;
    private TextView readingsText;
    private TextView feedbackText;
    private WritingCanvasView canvas;
    private View tools;
    private View doneRow;
    private Button outlineButton;
    private Button nextButton;
    private TextView summaryTitle;
    private TextView summaryList;
    private Button againButton;

    /**
     * The constructor.
     */
    public WritingPracticeActivity() {
        super(R.layout.activity_writing_practice, R.menu.generic_options_menu);
    }

    @Override
    protected void onCreateLocal(final @Nullable Bundle savedInstanceState) {
        startView = findViewById(R.id.writingStartView);
        questionView = findViewById(R.id.writingQuestionView);
        summaryView = findViewById(R.id.writingSummaryView);
        startStats = findViewById(R.id.writingStartStats);
        startButton = findViewById(R.id.writingStartButton);
        roundSize = findViewById(R.id.writingRoundSize);
        leniency = findViewById(R.id.writingLeniency);
        traceNew = findViewById(R.id.writingTraceNew);
        promptBand = findViewById(R.id.writingPromptBand);
        progressText = findViewById(R.id.writingProgress);
        levelText = findViewById(R.id.writingLevel);
        meaningText = findViewById(R.id.writingMeaning);
        readingsText = findViewById(R.id.writingReadings);
        feedbackText = findViewById(R.id.writingFeedback);
        canvas = findViewById(R.id.writingCanvas);
        tools = findViewById(R.id.writingTools);
        doneRow = findViewById(R.id.writingDoneRow);
        outlineButton = findViewById(R.id.writingOutline);
        nextButton = findViewById(R.id.writingNext);
        summaryTitle = findViewById(R.id.writingSummaryTitle);
        summaryList = findViewById(R.id.writingSummaryList);
        againButton = findViewById(R.id.writingAgain);

        // Keep the screens clear of Android's navigation bar (the app draws edge to edge).
        keepClearOfSystemBars(startView);
        keepClearOfSystemBars(questionView);
        keepClearOfSystemBars(summaryView);

        final SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        final int size = prefs.getInt("roundSize", 10);
        roundSize.check(size == 5 ? R.id.writingSize5 : size == 20 ? R.id.writingSize20 : R.id.writingSize10);
        final String len = prefs.getString("leniency", "normal");
        leniency.check("relaxed".equals(len) ? R.id.writingRelaxed : "strict".equals(len) ? R.id.writingStrict : R.id.writingNormal);
        traceNew.setChecked(prefs.getBoolean("traceNew", false));
        roundSize.setOnCheckedChangeListener((g, id) -> safe(this::saveSettings));
        leniency.setOnCheckedChangeListener((g, id) -> safe(this::saveSettings));
        traceNew.setOnCheckedChangeListener((b, c) -> safe(this::saveSettings));

        final int kanjiBg = SubjectType.WANIKANI_KANJI.getBackgroundColor();
        final int kanjiFg = SubjectType.WANIKANI_KANJI.getTextColor();
        promptBand.setBackgroundColor(kanjiBg);
        progressText.setTextColor(kanjiFg);
        levelText.setTextColor(kanjiFg);
        meaningText.setTextColor(kanjiFg);
        readingsText.setTextColor(kanjiFg);
        final int bg = ThemeUtil.getColor(R.attr.colorBackground);
        final boolean light = ThemeUtil.isLightColor(bg);
        final int paper = light ? 0xFFFFFFFF : 0xFF1E1E1E;
        final int ink = light ? 0xFF1B1F22 : 0xFFEDEDED;
        final int error = ThemeUtil.getColor(R.attr.incorrectColorBackground);
        canvas.setColors(paper, ink, kanjiBg, error == 0xFFFF0000 ? 0xFFD03030 : error);

        canvas.setListener(new WritingCanvasView.Listener() {
            @Override
            public void onFeedback(final String message, final int kind) {
                safe(() -> showFeedback(message, kind));
            }

            @Override
            public void onCompleted(final int mistakes, final int hints, final boolean revealed, final boolean traced) {
                safe(() -> finishItem(mistakes, hints, revealed, traced));
            }
        });

        startButton.setOnClickListener(v -> safe(() -> startRound(buildQueue())));
        findViewById(R.id.writingHint).setOnClickListener(v -> safe(canvas::hint));
        outlineButton.setOnClickListener(v -> safe(() -> canvas.setOutline(!canvas.isOutlineShown())));
        findViewById(R.id.writingRestart).setOnClickListener(v -> safe(canvas::restart));
        findViewById(R.id.writingReveal).setOnClickListener(v -> safe(canvas::reveal));
        findViewById(R.id.writingReplay).setOnClickListener(v -> safe(canvas::replay));
        nextButton.setOnClickListener(v -> safe(this::next));
        findViewById(R.id.writingDone).setOnClickListener(v -> safe(this::showStart));

        startLevelText = findViewById(R.id.writingStartLevel);
        gate = findViewById(R.id.writingGate);
        gate.check("passed".equals(prefs.getString("gate", "lesson")) ? R.id.writingGatePassed : R.id.writingGateLesson);
        gate.setOnCheckedChangeListener((g, id) -> safe(this::saveSettings));
        startLevel = prefs.getInt("startLevel", 0);
        findViewById(R.id.writingLevelDown).setOnClickListener(v -> safe(() -> changeStartLevel(-1)));
        findViewById(R.id.writingLevelUp).setOnClickListener(v -> safe(() -> changeStartLevel(1)));

        progress.clear();
        progress.putAll(WritingProgress.load(this));
        showStart();
        runAsync(this, WritingPracticeActivity::loadCandidates, loaded -> safe(() -> {
            if (loaded != null) {
                allItems = loaded.items;
                userLevel = Math.max(1, loaded.userLevel);
            }
            if (startLevel <= 0) {
                // First time: start writing practice at the level you're on now.
                startLevel = userLevel;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("startLevel", startLevel).apply();
            }
            refilter();
            updateStartScreen();
        }));
    }

    private static void keepClearOfSystemBars(final View view) {
        final int left = view.getPaddingLeft();
        final int top = view.getPaddingTop();
        final int right = view.getPaddingRight();
        final int bottom = view.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(view, (v, insets) -> {
            final Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(left + bars.left, top, right + bars.right, bottom + bars.bottom);
            return insets;
        });
        ViewCompat.requestApplyInsets(view);
    }

    /* ---------- data ---------- */

    private static Loaded loadCandidates() {
        final Loaded loaded = new Loaded();
        loaded.userLevel = WkApplication.getDatabase().propertiesDao().getUserLevel();
        final List<Item> out = loaded.items;
        final List<Subject> subjects = WkApplication.getDatabase().subjectCollectionsDao().getByLevelRange(1, 60);
        for (final Subject s: subjects) {
            if (!s.getType().isKanji() || s.getStartedAt() == 0 || !s.hasStrokeData()) {
                continue;
            }
            final @Nullable String chars = s.getCharacters();
            if (chars == null || chars.isEmpty()) {
                continue;
            }
            final Item item = new Item();
            item.characters = chars;
            item.level = s.getLevel();
            item.started = s.getStartedAt() != 0;
            item.passed = s.isPassed();
            final List<String> meanings = new ArrayList<>();
            String primary = "";
            for (final Meaning m: s.getMeanings()) {
                final @Nullable String v = m.getMeaning();
                if (v == null || !m.isAcceptedAnswer()) {
                    continue;
                }
                if (m.isPrimary() && primary.isEmpty()) {
                    primary = v;
                }
                else {
                    meanings.add(v);
                }
            }
            if (primary.isEmpty() && !meanings.isEmpty()) {
                primary = meanings.remove(0);
            }
            item.meaning = primary;
            item.otherMeanings = join(meanings.size() > 2 ? meanings.subList(0, 2) : meanings);
            item.onyomi = readings(s.getOnYomiReadings());
            item.kunyomi = readings(s.getKunYomiReadings());
            item.strokes = new ArrayList<>(s.getParsedStrokeData());
            out.add(item);
        }
        Collections.sort(out, (a, b) -> Integer.compare(a.level, b.level));
        return loaded;
    }

    private void refilter() {
        final boolean needPassed = gate.getCheckedRadioButtonId() == R.id.writingGatePassed;
        final List<Item> list = new ArrayList<>();
        for (final Item i: allItems) {
            if (i.level >= startLevel && (needPassed ? i.passed : i.started)) {
                list.add(i);
            }
        }
        candidates = list;
    }

    private void changeStartLevel(final int delta) {
        final int top = Math.max(1, userLevel);
        startLevel = Math.max(1, Math.min(top, (startLevel <= 0 ? top : startLevel) + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("startLevel", startLevel).apply();
        refilter();
        updateStartScreen();
    }

    private static String readings(final List<Reading> list) {
        final List<String> out = new ArrayList<>();
        for (final Reading r: list) {
            final @Nullable String v = r.getReading();
            if (v != null && !v.isEmpty() && !out.contains(v)) {
                out.add(v);
            }
        }
        return join(out);
    }

    private static String join(final List<String> list) {
        final StringBuilder sb = new StringBuilder();
        for (final String s: list) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(s);
        }
        return sb.toString();
    }

    private void saveProgress() {
        WritingProgress.save(this, progress);
    }

    private void saveSettings() {
        final int id = roundSize.getCheckedRadioButtonId();
        final int lid = leniency.getCheckedRadioButtonId();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("roundSize", id == R.id.writingSize5 ? 5 : id == R.id.writingSize20 ? 20 : 10)
                .putString("leniency", lid == R.id.writingRelaxed ? "relaxed" : lid == R.id.writingStrict ? "strict" : "normal")
                .putBoolean("traceNew", traceNew.isChecked())
                .putString("gate", gate.getCheckedRadioButtonId() == R.id.writingGatePassed ? "passed" : "lesson")
                .apply();
        refilter();
        updateStartScreen();
    }

    private int getRoundSize() {
        final int id = roundSize.getCheckedRadioButtonId();
        return id == R.id.writingSize5 ? 5 : id == R.id.writingSize20 ? 20 : 10;
    }

    private float getTolerance() {
        final int id = leniency.getCheckedRadioButtonId();
        return id == R.id.writingRelaxed ? 21f : id == R.id.writingStrict ? 12f : 16f;
    }

    private List<Item> buildQueue() {
        final long now = System.currentTimeMillis();
        final List<Item> due = new ArrayList<>();
        final List<Item> fresh = new ArrayList<>();
        for (final Item item: candidates) {
            final @Nullable long[] p = progress.get(item.characters);
            if (p == null) {
                fresh.add(item);
            }
            else if (p[1] <= now) {
                due.add(item);
            }
        }
        Collections.sort(due, (a, b) -> {
            final @Nullable long[] pa = progress.get(a.characters);
            final @Nullable long[] pb = progress.get(b.characters);
            return Long.compare(pa == null ? 0 : pa[1], pb == null ? 0 : pb[1]);
        });
        final List<Item> q = new ArrayList<>();
        final int size = getRoundSize();
        for (final Item i: due) {
            if (q.size() >= size) {
                break;
            }
            q.add(i);
        }
        for (final Item i: fresh) {
            if (q.size() >= size) {
                break;
            }
            q.add(i);
        }
        Collections.shuffle(q);
        return q;
    }

    /* ---------- screens ---------- */

    private void showStart() {
        startView.setVisibility(View.VISIBLE);
        ViewCompat.requestApplyInsets(startView);
        questionView.setVisibility(View.GONE);
        summaryView.setVisibility(View.GONE);
        updateStartScreen();
    }

    private void updateStartScreen() {
        final long now = System.currentTimeMillis();
        int due = 0;
        int fresh = 0;
        for (final Item item: candidates) {
            final @Nullable long[] p = progress.get(item.characters);
            if (p == null) {
                fresh++;
            }
            else if (p[1] <= now) {
                due++;
            }
        }
        startLevelText.setText(String.format(Locale.ROOT, "Level %d", Math.max(1, startLevel)));
        if (candidates.isEmpty()) {
            startStats.setText("No kanji to practise yet from this level on. Kanji join after their WaniKani lesson (or once passed, if you chose that). Lower the starting level to include earlier kanji.");
            startButton.setEnabled(false);
            startButton.setText("Start");
            return;
        }
        startStats.setText(String.format(Locale.ROOT, "%d kanji from level %d onwards\n%d due for writing review · %d not written yet",
                candidates.size(), Math.max(1, startLevel), due, fresh));
        final int n = Math.min(getRoundSize(), due + fresh);
        startButton.setEnabled(n > 0);
        startButton.setText(n > 0 ? String.format(Locale.ROOT, "Start · %d kanji", n) : "Nothing due right now");
    }

    private void startRound(final List<Item> q) {
        if (q.isEmpty()) {
            return;
        }
        queue = q;
        index = 0;
        results.clear();
        startView.setVisibility(View.GONE);
        summaryView.setVisibility(View.GONE);
        questionView.setVisibility(View.VISIBLE);
        ViewCompat.requestApplyInsets(questionView);
        loadItem();
    }

    private void loadItem() {
        final Item item = queue.get(index);
        final boolean isNew = !progress.containsKey(item.characters);
        progressText.setText(String.format(Locale.ROOT, "%d / %d", index + 1, queue.size()));
        levelText.setText(String.format(Locale.ROOT, "Level %d%s", item.level, isNew ? " · new" : ""));
        meaningText.setText(item.otherMeanings.isEmpty() ? item.meaning : item.meaning + "\n" + item.otherMeanings);
        final StringBuilder r = new StringBuilder();
        if (!item.onyomi.isEmpty()) {
            r.append("on: ").append(item.onyomi);
        }
        if (!item.kunyomi.isEmpty()) {
            if (r.length() > 0) {
                r.append("   ");
            }
            r.append("kun: ").append(item.kunyomi);
        }
        readingsText.setText(r.toString());
        final boolean outline = isNew && traceNew.isChecked();
        canvas.setTolerance(getTolerance());
        canvas.setStrokeData(item.strokes, outline);
        tools.setVisibility(View.VISIBLE);
        doneRow.setVisibility(View.GONE);
        final int n = canvas.getStrokeCount();
        showFeedback(String.format(Locale.ROOT, "%d stroke%s. %s", n, n == 1 ? "" : "s",
                outline ? "Trace over the outline." : "Write it from scratch."), 0);
    }

    private void showFeedback(final String message, final int kind) {
        if (defaultFeedbackColor == 0) {
            defaultFeedbackColor = feedbackText.getCurrentTextColor();
        }
        feedbackText.setText(message);
        if (kind == 0) {
            feedbackText.setTextColor(defaultFeedbackColor);
            return;
        }
        final int color = ThemeUtil.getColor(kind == 2 ? R.attr.incorrectColorBackground : R.attr.correctColorBackground);
        feedbackText.setTextColor(color == 0xFFFF0000 && kind == 1 ? 0xFF2C7650 : color);
    }

    private void finishItem(final int mistakes, final int hints, final boolean revealed, final boolean traced) {
        final Item item = queue.get(index);
        final int slips = mistakes + hints;
        final String outcome = revealed ? "fail" : slips == 0 ? "clean" : "miss";
        WritingProgress.record(progress, item.characters, outcome, slips, traced ? 1 : 0);
        saveProgress();
        results.add(new Result(item, outcome, slips));

        final String msg;
        if ("clean".equals(outcome)) {
            msg = traced ? item.characters + "  Traced cleanly. Next time, from scratch." : item.characters + "  Correct! Every stroke in order.";
        }
        else if ("miss".equals(outcome)) {
            msg = String.format(Locale.ROOT, "%s  Done with %d mistake%s%s.", item.characters, mistakes, mistakes == 1 ? "" : "s",
                    hints > 0 ? String.format(Locale.ROOT, " and %d hint%s", hints, hints == 1 ? "" : "s") : "");
        }
        else {
            msg = item.characters + "  Shown. It will come back soon.";
        }
        showFeedback(msg, "clean".equals(outcome) ? 1 : "fail".equals(outcome) ? 2 : 0);
        tools.setVisibility(View.GONE);
        doneRow.setVisibility(View.VISIBLE);
        nextButton.setText(index + 1 < queue.size() ? "Next" : "See results");
    }

    private void next() {
        index++;
        if (index >= queue.size()) {
            showSummary();
            return;
        }
        loadItem();
    }

    private void showSummary() {
        startView.setVisibility(View.GONE);
        questionView.setVisibility(View.GONE);
        summaryView.setVisibility(View.VISIBLE);
        ViewCompat.requestApplyInsets(summaryView);
        int clean = 0;
        final StringBuilder sb = new StringBuilder();
        final List<Item> misses = new ArrayList<>();
        for (final Result r: results) {
            if ("clean".equals(r.outcome)) {
                clean++;
            }
            else {
                misses.add(r.item);
            }
            final String mark = "clean".equals(r.outcome) ? "✓" : "fail".equals(r.outcome) ? "✗ shown" : "△ " + r.slips + " slip" + (r.slips == 1 ? "" : "s");
            sb.append(r.item.characters).append("  ").append(r.item.meaning).append("  ").append(mark).append('\n');
        }
        summaryTitle.setText(String.format(Locale.ROOT, "%d of %d written cleanly", clean, results.size()));
        summaryList.setText(sb.toString().trim());
        againButton.setVisibility(misses.isEmpty() ? View.GONE : View.VISIBLE);
        againButton.setOnClickListener(v -> safe(() -> {
            final List<Item> q = new ArrayList<>(misses);
            Collections.shuffle(q);
            startRound(q);
        }));
    }

    @Override
    protected void onResumeLocal() {
        //
    }

    @Override
    protected void onPauseLocal() {
        //
    }

    @Override
    protected void enableInteractionLocal() {
        //
    }

    @Override
    protected void disableInteractionLocal() {
        //
    }

    @Override
    protected boolean showWithoutApiKey() {
        return false;
    }
}

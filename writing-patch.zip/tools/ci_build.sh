#!/usr/bin/env bash
# Build script run by .github/workflows/build.yml (lives in writing-patch.zip so it can change without touching the workflow).
set -euo pipefail
OUT="${RUNNER_TEMP:-/tmp}/out"
mkdir -p "$OUT" ~/.android
if [ -f tools/signing.keystore.b64 ]; then base64 -d tools/signing.keystore.b64 > ~/.android/debug.keystore; fi
# Each build gets a higher version number so Android treats it as an update.
if [ -n "${GITHUB_RUN_NUMBER:-}" ]; then
  sed -i -E "s/versionCode [0-9]+/versionCode $((1000 + GITHUB_RUN_NUMBER))/" app/build.gradle
  sed -i -E "s/versionName '([^']*)'/versionName '\1-w${GITHUB_RUN_NUMBER}'/" app/build.gradle
fi
chmod +x gradlew
./gradlew assembleRelease --no-daemon --stacktrace
cp app/build/outputs/apk/release/*.apk "$OUT/durtles-writing.apk"
ls -la "$OUT"
